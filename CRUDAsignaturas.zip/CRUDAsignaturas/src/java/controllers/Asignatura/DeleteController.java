/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers.Asignatura;

import Models.Conexion;
import javax.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author sergioandres
 */

public class DeleteController {
    private JdbcTemplate jdbcTemp;
    
    public DeleteController() {
        this.jdbcTemp = new JdbcTemplate(new Conexion().conectar());
    }
    
    @RequestMapping("delete.htm")
    public ModelAndView delete(HttpServletRequest request) {
        String codigo = request.getParameter("codigo");
        this.jdbcTemp.update(
                    "delete from asignatura "
                + "where "
                + "codigo=? ",
        codigo);
        return new ModelAndView("redirect:/");
    }
}
