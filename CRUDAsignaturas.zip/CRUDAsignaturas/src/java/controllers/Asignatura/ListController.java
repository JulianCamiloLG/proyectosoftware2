/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers.Asignatura;

import Models.Conexion;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author sergioandres
 */
public class ListController {
    private JdbcTemplate jdbcTemp;
    
    public ListController() {
        this.jdbcTemp = new JdbcTemplate(new Conexion().conectar());
    }
    
    @RequestMapping("list.htm")
    public ModelAndView home()
    {
        ModelAndView mav=new ModelAndView();
        String sql="select * from asignaturas";
        List asignatura=this.jdbcTemp.queryForList(sql);
        mav.addObject("asignatura",asignatura);
        mav.setViewName("Asignatura/list");
        return mav;
    }
}
