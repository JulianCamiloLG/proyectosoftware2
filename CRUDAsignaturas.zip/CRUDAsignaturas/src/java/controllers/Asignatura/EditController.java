/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers.Asignatura;

import Models.Conexion;
import Models.Asignatura;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.http.HttpServletRequest;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author sergioandres
 */
public class EditController {

    private JdbcTemplate jdbcTemp;

    public EditController() {
        this.jdbcTemp = new JdbcTemplate(new Conexion().conectar());
    }

    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView form(HttpServletRequest request) {
        ModelAndView mav = new ModelAndView();
        String codigo = request.getParameter("codigo");
        Asignatura est = this.selectEst(codigo);
        mav.setViewName("Asignatura/edit");
        Asignatura newAsig = new Asignatura(est.getCodigo(), est.getNombre(), est.getCreditos());
        mav.addObject("asignatura", newAsig);
        return mav;
    }

    @RequestMapping(method = RequestMethod.POST)
    public ModelAndView form(
            @ModelAttribute("Asignatura") Asignatura e,
            BindingResult result,
            SessionStatus status,
            HttpServletRequest request
    ) {

        String codigo = request.getParameter("codigo");
        this.jdbcTemp.update(
                "update asignatura "
                + "set nombre=?,"
                + "creditos=?,",
                e.getNombre(), e.getCreditos(), codigo);
        return new ModelAndView("redirect:/");
    }

    public Asignatura selectEst(String codigo) {
        final Asignatura asig = new Asignatura();
        String query = "SELECT * FROM asignatura WHERE codigo='" + codigo + "'";
        return (Asignatura) jdbcTemp.query(query, new ResultSetExtractor<Asignatura>() {
            public Asignatura extractData(ResultSet rs) throws SQLException, DataAccessException {
                if (rs.next()) {
                    asig.setCodigo(rs.getString("codigo"));
                    asig.setNombre(rs.getString("nombre"));
                    asig.setCreditos(rs.getInt("creditos"));
                }
                return asig;
            }
        }
        );
    }
}
